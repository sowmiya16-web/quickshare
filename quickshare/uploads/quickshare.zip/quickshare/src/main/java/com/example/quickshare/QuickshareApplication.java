package com.example.quickshare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickshareApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickshareApplication.class, args);
	}

}
